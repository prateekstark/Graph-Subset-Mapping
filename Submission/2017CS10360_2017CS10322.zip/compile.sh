g++ -std=c++11 main.cpp

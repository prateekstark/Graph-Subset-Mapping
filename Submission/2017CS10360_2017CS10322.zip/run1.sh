./a.out generateInput $1

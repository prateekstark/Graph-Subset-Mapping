./a.out generateOutput $1
